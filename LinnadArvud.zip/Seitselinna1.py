#IrisMariaRohelpuu

linn = ["Elva", "Tartu", "Püssi",  "Tallinn", "Haapsalu", "Tapa", "Antsla"]

tähestik = sorted(["Elva", "Tartu", "Püssi",  "Tallinn", "Haapsalu", "Tapa", "Antsla"])
print("Antud linnad tähestikulises järjekorras on: " + str(tähestik))

mitu = len(["Elva", "Tartu", "Püssi",  "Tallinn", "Haapsalu", "Tapa", "Antsla"])
print("Antud järjendis on " + str(mitu) + " linna.")