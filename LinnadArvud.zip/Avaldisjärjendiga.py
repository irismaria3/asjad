#IrisMariaRohelpuu

a = [2, 3, 1, 5]
b = [6, 4]

korras = sorted(a + b)
print(korras)