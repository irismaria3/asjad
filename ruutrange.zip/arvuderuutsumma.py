#IrisMariaRohelpuu

täisarv = int(input("Palun sisestage täisarv: "))
summa = 0

for i in range(1, täisarv + 1):
    ruut = i**2
    summa += ruut
    print("Arvu", i, "ruut on", ruut)

print("Arvude ruutude summa on", summa)