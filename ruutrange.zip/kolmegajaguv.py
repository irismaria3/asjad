#IrisMariaRohelpuu

i = 0
kolm = list(range(12, 100, 3))

for i in kolm:
    print("Kolmega jagub",i)

