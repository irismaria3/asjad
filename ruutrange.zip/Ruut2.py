#IrisMariaRohelpuu
from turtle import*

for el in range(4):
    forward(100)
    left(90)