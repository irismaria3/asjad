#IrisMariaRohelpuu

print(list(range(100, 9, -7)))