#IrisMariaRohelpuu

nimekiri = ['Malle', 'Kalle', 'Sandra', 'Anneli', 'Joonas']

nimekiri.append('Kaarel')
nimekiri[2] = 'Juku'

print(nimekiri)