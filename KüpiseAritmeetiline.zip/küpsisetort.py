#IrisMariaRohelpuu
import math

laius = int(input("Palun sisestage mitu küpsist mahub kandikule laiuses: "))
pikkus = int(input("Palun sisestage mitu küpsist mahub kandikule pikkuses: "))
kiht = int(input("Palun sisestage mitme kihilist torti teha soovite: "))
küpsis = int(input("Palun isestage mitu küpsist on pakis: "))

mitupakki = (laius * pikkus * kiht) / küpsis
ümardatult = math.ceil(mitupakki)

print("Küpsisetordi tegemiseks läheb " + str(ümardatult) + " pakki küpsiseid.")


#Tegime kõrvuti Cassandraga ja kasutasime mõlemad math.ceil-i
#(Palun mitte plagiaati!)