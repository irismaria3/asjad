#IrisMariaRohelpuu

sisestus = ""
summa = 0
loendur = 0
while True:
    hinne = input("Palun sisesta üks hinne: ")
    if hinne == "stop":
        break
    summa += int(hinne)
    loendur += 1

aritmeetiline = summa / loendur
print("Sinu keskmine hinne on " + str(aritmeetiline))

    
