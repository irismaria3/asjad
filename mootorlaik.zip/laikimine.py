#IrisMariaRohelpuu #EliisaRaal

min = int(input("Palun sisestage möödunud minutite arv: "))
summa = 0

for like in range(1, min + 1, 2):
    summa = summa + like

print(summa)
    
    