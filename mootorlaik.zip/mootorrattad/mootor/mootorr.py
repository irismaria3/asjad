#IrisMariaRohelpuu #EliisaRaal

fail = open("mootor.txt", encoding = "UTF-8-SIG")

kuu = int(input("Palun sisestage kuu number: "))
mootorrattad = []

for rida in fail:
    mootorrattad.append(int(rida))

fail.close()

mootorrattad[kuu - 1]
print(str(kuu), ". kuu mootorrattaste arv on", str(mootorrattad[kuu - 1]) )