#IrisMariaRohelpuu #EliisaRaal

fail = open("konto.txt", encoding = "UTF-8-SIG") #Kõigepealt avan faili, kuhu olen eelnevalt salvestanud vajalikud arvud.

for el in fail:    #Hakkan võtma rea kaupa failist elemente
    if float(el) > 0:   #Kontrollin kas element on suurem kui null ehk kas tegu on positiive arvuga
        print(el.strip())  #Väljastan positiivse elemendi ja eemaldan .strip() käsuga reavahed